package entities.interfaces;

public interface Tank extends Machine {

    boolean getDefenseMode();

    void toggleDefenseMode();
}
